/**
 * 用户认证 & 授权模块 (v1.9.0 安全加固版)
 *
 * v1.9.0 变更:
 *   - 普通用户登录改走 Supabase Auth REST (假邮箱 username@beidanci.local + bcrypt)
 *   - 注册/老用户迁移统一走 migrate-user Edge Function
 *     (admin API 建账号时 email_confirm=true, 不依赖 Dashboard "Confirm email" 开关)
 *   - 老用户首次登录自动迁移 (verify_login 兜底校验 → migrate-user → signIn)
 *   - 会话由 access_token/refresh_token/uid 三元组管理 (RLS 强隔离核心)
 *   - 改密/找回密码走 update-password Edge Function (同步更新 bcrypt + 旧 SHA-256 哈希)
 *   - admin 保留旧机制 (verify_login + KEY_PWD_HASH), 不进 Supabase Auth
 *
 * 功能: 登录/注册/找回密码、授权检查、捐赠引导、管理员留言
 *
 * v1.11.0 ES Module 重构: 保留 window.App.Auth 命名空间, 由 main.js 静态 import 加载;
 *   auth.js 注入 auth overlay HTML 的 _showOverlay/_showAuthCard 逻辑保持不变, 运行时查找 window.App
 */
window.App = window.App || {};
App.Auth = (function () {

  var CFG = App.Config;
  var AUTH = CFG.AUTH;
  var _appStarted = false;

  function _esc(text) { return App.Utils.escapeHtml(text); }

  function _showOverlay(html) {
    var overlay = document.getElementById('authOverlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'authOverlay';
      document.body.appendChild(overlay);
    }
    overlay.innerHTML = html;
    overlay.classList.remove('hidden');
    overlay.style.display = 'flex';
  }

  function _hideOverlay() {
    var overlay = document.getElementById('authOverlay');
    if (!overlay) return;
    overlay.classList.add('hidden');
    overlay.style.display = 'none';
    overlay.innerHTML = '';
  }

  function _showAuthCard(title, subtitle, bodyHtml) {
    var html =
      '<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(135deg,#4A90D9,#357ABD);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px;box-sizing:border-box;"> ' +
        '<div style="background:#fff;border-radius:12px;padding:28px 24px;width:100%;max-width:360px;box-shadow:0 8px 32px rgba(0,0,0,0.2);max-height:90vh;overflow-y:auto;"> ' +
          '<h2 style="text-align:center;font-size:22px;color:#333;margin-bottom:6px;">' + _esc(title) + '</h2>' +
          (subtitle ? '<p style="text-align:center;font-size:13px;color:#999;margin-bottom:20px;">' + _esc(subtitle) + '</p>' : '') +
          bodyHtml +
        '</div>' +
      '</div>';
    _showOverlay(html);
  }

  // ========== v1.9.0: Supabase Auth REST 调用 (手动 fetch, 不引入 SDK) ==========

  /** 假邮箱拼接: 用户名 → username@beidanci.local (不发真实邮件, 仅作 Auth 唯一键) */
  function _fakeEmail(username) {
    return username + '@' + AUTH.EMAIL_DOMAIN;
  }

  /** 提取 Supabase Auth 错误信息 (兼容新旧版本响应格式) */
  function _authErrMsg(data, fallback) {
    if (!data) return fallback;
    return data.error_description || data.msg || data.message || data.error || data.code || fallback;
  }

  /**
   * Supabase Auth 密码登录 → 拿 access_token/refresh_token/uid
   * @returns {Promise<{access_token, refresh_token, user, expires_in}>}
   */
  async function _authSignIn(email, password) {
    var resp = await fetch(
      App.DBConfig.getUrl().replace(/\/+$/, '') + '/auth/v1/token?grant_type=password',
      {
        method: 'POST',
        headers: {
          'apikey': App.DBConfig.getKey(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: email, password: password }),
      }
    );
    var data = null;
    try { data = await resp.json(); } catch (e) { data = null; }
    if (!resp.ok) {
      // 常见错误: Invalid credentials / Email not confirmed
      throw new Error(_authErrMsg(data, '登录失败 (HTTP ' + resp.status + ')'));
    }
    if (!data || !data.access_token) {
      throw new Error('登录响应缺少 access_token');
    }
    return data;
  }

  // ========== 会话存储 ==========

  function _clearAuthStorage() {
    localStorage.removeItem(CFG.KEY_USERNAME);
    localStorage.removeItem(CFG.KEY_PWD_HASH);
    localStorage.removeItem(CFG.KEY_SYNC_CODE);
    if (App.DB && typeof App.DB.clearAuthSession === 'function') App.DB.clearAuthSession();
  }

  function _startApp() {
    if (_appStarted) return;
    _appStarted = true;
    if (typeof App.initializeApp === 'function') App.initializeApp();
  }

  async function _afterLoginSuccess(username) {
    var status = await checkAuth(username);
    if (status === 'authorized' || status === 'admin' || status === 'trial') {
      _hideOverlay(); _startApp(); showMessagesPopup(username);
    } else {
      showDonationPage();
    }
  }

  // ========== 初始化: 本地会话恢复 ==========

  async function init() {
    if (isLoggedIn()) {
      var username = localStorage.getItem(CFG.KEY_USERNAME);
      try {
        // admin: 旧机制恢复 (无 JWT, 必须用 verify_login 校验 KEY_PWD_HASH, 同步等待)
        if (username === AUTH.ADMIN_CODE) {
          var adminPwdHash = localStorage.getItem(CFG.KEY_PWD_HASH);
          var adminResult = await App.DB.verifyLogin(username, adminPwdHash);
          if (adminResult.success) { await _afterLoginSuccess(username); return; }
        } else if (App.DB.getUserId() && App.DB.getAccessToken()) {
          // v1.11.1 性能优化: 普通用户本地有 JWT 时, 不再阻塞首屏等 checkAuth RPC
          // 立即 _startApp 渲染 app shell, checkAuth 后台异步校验
          // access_token 过期由 db.js 在 401 时用 refresh_token 自动刷新
          _hideOverlay();
          _startApp();
          // 后台校验授权状态 (失败再弹回捐赠/登录页)
          checkAuth(username).then(function (status) {
            if (status === 'authorized' || status === 'admin' || status === 'trial') {
              showMessagesPopup(username);
            } else {
              // 授权失效 (过期/吊销), 弹回捐赠页
              _appStarted = false; // 允许下次重新启动
              showDonationPage();
            }
          }).catch(function (e) {
            console.error('[Auth] 后台 checkAuth 失败, 维持当前会话 (401 时 db.js 会处理):', e);
          });
          return;
        }
      } catch (e) { console.error('[Auth] init 会话恢复失败:', e); }
      _clearAuthStorage();
    }
    showLoginPage();
  }

  function hashPassword(username, password) { return App.Utils.sha256(username + password + AUTH.APP_SALT); }

  // ========== 登录页 UI ==========

  function showLoginPage() {
    var html =
      '<div class="auth-overlay" style="position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(135deg,#4A90D9,#357ABD);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px;box-sizing:border-box;"> ' +
        '<div class="auth-card" style="background:#fff;border-radius:12px;padding:32px 24px;width:100%;max-width:340px;box-shadow:0 8px 32px rgba(0,0,0,0.2);"> ' +
          '<h2 style="text-align:center;font-size:24px;color:#333;margin-bottom:6px;">背单词</h2>' +
          '<p style="text-align:center;font-size:13px;color:#999;margin-bottom:24px;">登录以开始学习</p>' +
          '<div class="auth-form">' +
            '<div style="margin-bottom:14px;"><input type="text" id="loginUsername" placeholder="用户名" autocomplete="off" style="width:100%;padding:12px 14px;font-size:15px;border:1px solid #E0E0E0;border-radius:6px;box-sizing:border-box;"></div>' +
            '<div style="margin-bottom:20px;"><input type="password" id="loginPassword" placeholder="密码" style="width:100%;padding:12px 14px;font-size:15px;border:1px solid #E0E0E0;border-radius:6px;box-sizing:border-box;"></div>' +
            '<button id="btnLogin" style="width:100%;padding:12px;background:#4A90D9;color:#fff;border:none;border-radius:6px;font-size:16px;font-weight:500;cursor:pointer;">登录</button>' +
            '<div style="display:flex;justify-content:space-between;margin-top:16px;font-size:13px;"><a href="#" id="linkRegister" style="color:#4A90D9;text-decoration:none;">注册新账户</a><a href="#" id="linkForgot" style="color:#4A90D9;text-decoration:none;">忘记密码</a></div>' +
          '</div>' +
        '</div>' +
      '</div>';
    _showOverlay(html);
    document.getElementById('btnLogin').addEventListener('click', _handleLogin);
    document.getElementById('loginPassword').addEventListener('keydown', function (e) { if (e.key === 'Enter') _handleLogin(); });
    document.getElementById('linkRegister').addEventListener('click', function (e) { e.preventDefault(); showRegisterPage(); });
    document.getElementById('linkForgot').addEventListener('click', function (e) { e.preventDefault(); showForgotPasswordPage(); });
    setTimeout(function () { var u = document.getElementById('loginUsername'); if (u) u.focus(); }, 100);
  }

  async function _handleLogin() {
    var username = document.getElementById('loginUsername').value.trim();
    var password = document.getElementById('loginPassword').value;
    if (!username || !password) { App.showToast('请输入用户名和密码', 'error'); return; }
    var btn = document.getElementById('btnLogin');
    btn.disabled = true; btn.textContent = '登录中...';
    try {
      var ok = await login(username, password);
      if (ok) { App.showToast('登录成功', 'success'); await _afterLoginSuccess(username); }
    } catch (e) { App.showToast('登录失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '登录'; }
  }

  // ========== 注册页 UI ==========

  function showRegisterPage() {
    var options = '';
    for (var i = 0; i < CFG.SEC_QUESTIONS.length; i++) options += '<option value="' + i + '">' + _esc(CFG.SEC_QUESTIONS[i]) + '</option>';
    var body =
      '<div class="form-group"><label>用户名</label><input type="text" id="regUsername" placeholder="请输入用户名" autocomplete="off"><p class="form-hint">用户名用于云端同步学习数据, 请妥善保管</p></div>' +
      '<div class="form-group"><label>密码</label><input type="password" id="regPassword" placeholder="请输入密码"></div>' +
      '<div class="form-group"><label>确认密码</label><input type="password" id="regPassword2" placeholder="再次输入密码"></div>' +
      '<div class="form-group"><label>密保问题</label><select id="regSecQuestion">' + options + '</select></div>' +
      '<div class="form-group"><label>密保答案</label><input type="text" id="regSecAnswer" placeholder="请输入密保答案" autocomplete="off"><p class="form-hint">用于找回密码, 不区分大小写</p></div>' +
      '<div class="form-actions"><button class="btn btn-outline" id="btnRegBack">返回登录</button><button class="btn btn-primary" id="btnRegSubmit">注册</button></div>';
    _showAuthCard('注册新账户', null, body);
    document.getElementById('btnRegBack').addEventListener('click', showLoginPage);
    document.getElementById('btnRegSubmit').addEventListener('click', _handleRegister);
  }

  /**
   * v1.9.0 注册流程 (不依赖 Dashboard "Confirm email" 开关):
   *   1. user_auth 查重 (RPC)
   *   2. register_user RPC: 存入 user_auth (密保 + 旧哈希, user_id 先留空)
   *   3. migrate-user Edge Function:
   *      - verify_login 用旧哈希校验 (刚注册, 必然通过)
   *      - admin API 建 Auth 账号, email_confirm=true (service_role 强制确认, 绕过 Dashboard 开关)
   *      - 回填 user_auth / words / records 的 user_id
   *   4. Supabase Auth signIn 拿 JWT (账号已确认, 必然成功)
   *   5. 存会话
   */
  async function _handleRegister() {
    var username = document.getElementById('regUsername').value.trim();
    var password = document.getElementById('regPassword').value;
    var password2 = document.getElementById('regPassword2').value;
    var secQIdx = parseInt(document.getElementById('regSecQuestion').value, 10);
    var secAnswer = document.getElementById('regSecAnswer').value.trim();
    if (!username) { App.showToast('请输入用户名', 'error'); return; }
    if (!password) { App.showToast('请输入密码', 'error'); return; }
    if (password !== password2) { App.showToast('两次密码不一致', 'error'); return; }
    if (!secAnswer) { App.showToast('请输入密保答案', 'error'); return; }
    if (username === AUTH.ADMIN_CODE) { App.showToast('该用户名已被保留', 'error'); return; }

    var btn = document.getElementById('btnRegSubmit'); btn.disabled = true; btn.textContent = '注册中...';
    try {
      // 1. user_auth 查重
      var exists = await App.DB.usernameExists(username);
      if (exists) { App.showToast('用户名已存在', 'error'); return; }

      // 2. 写入 user_auth (密保 + 旧哈希, user_id 留空, 等 migrate-user 回填)
      var pwdHash = await hashPassword(username, password);
      var secAnswerHash = await App.Utils.sha256(secAnswer.toLowerCase());
      var secQuestion = CFG.SEC_QUESTIONS[secQIdx];
      await App.DB.registerUser(username, pwdHash, secQuestion, secAnswerHash, null);

      // 3. migrate-user: verify_login 校验 → admin API 建已确认 Auth 账号 → 回填 user_id
      var migResult = await App.DB.migrateUser(username, password, pwdHash);
      if (!migResult || !migResult.success) {
        throw new Error((migResult && migResult.error) || '注册失败: 建账号失败');
      }

      // 4. signIn 拿 JWT (账号已通过 admin API 确认, 不再依赖 Dashboard 邮箱确认开关)
      var email = _fakeEmail(username);
      var session = await _authSignIn(email, password);

      // 5. 存会话
      App.DB.setAuthSession(session.user.id, session.access_token, session.refresh_token);
      localStorage.setItem(CFG.KEY_USERNAME, username);
      localStorage.setItem(CFG.KEY_PWD_HASH, pwdHash);
      App.DB.setSyncCode(username);
      App.showToast('注册成功, 欢迎使用!', 'success');
      await _afterLoginSuccess(username);
    } catch (e) {
      var msg = e && e.message ? e.message : String(e);
      // Auth 账号已存在或用户名已存在
      if (msg.indexOf('already') >= 0 || msg.indexOf('exists') >= 0) {
        App.showToast('用户名已存在', 'error');
      } else {
        App.showToast('注册失败: ' + msg, 'error');
      }
    } finally { btn.disabled = false; btn.textContent = '注册'; }
  }

  // ========== 找回密码 UI (密保兜底) ==========

  function showForgotPasswordPage() { _forgotStep1(); }

  function _forgotStep1() {
    var body =
      '<div class="form-group"><label>用户名</label><input type="text" id="forgotUsername" placeholder="请输入用户名" autocomplete="off"></div>' +
      '<div class="form-actions"><button class="btn btn-outline" id="btnForgotBack">返回登录</button><button class="btn btn-primary" id="btnForgotNext">下一步</button></div>';
    _showAuthCard('找回密码 (1/3)', '通过密保问题重置密码', body);
    document.getElementById('btnForgotBack').addEventListener('click', showLoginPage);
    document.getElementById('btnForgotNext').addEventListener('click', _forgotStep1Next);
  }

  async function _forgotStep1Next() {
    var username = document.getElementById('forgotUsername').value.trim();
    if (!username) { App.showToast('请输入用户名', 'error'); return; }
    var btn = document.getElementById('btnForgotNext'); btn.disabled = true; btn.textContent = '查询中...';
    try {
      var result = await App.DB.getSecQuestion(username);
      if (!result || !result.success) { App.showToast('用户名不存在', 'error'); return; }
      _forgotStep2(username, result.question);
    } catch (e) { App.showToast('查询失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '下一步'; }
  }

  function _forgotStep2(username, question) {
    var body =
      '<div class="form-group"><label>密保问题</label><p style="padding:10px 12px;background:var(--color-border-light);border-radius:4px;font-size:14px;color:#333;">' + _esc(question) + '</p></div>' +
      '<div class="form-group"><label>密保答案</label><input type="text" id="forgotAnswer" placeholder="请输入密保答案" autocomplete="off"></div>' +
      '<div class="form-actions"><button class="btn btn-outline" id="btnForgotPrev">上一步</button><button class="btn btn-primary" id="btnForgotVerify">验证</button></div>';
    _showAuthCard('找回密码 (2/3)', '请回答密保问题', body);
    document.getElementById('btnForgotPrev').addEventListener('click', function () { _forgotStep1(); var u = document.getElementById('forgotUsername'); if (u) u.value = username; });
    document.getElementById('btnForgotVerify').addEventListener('click', function () { _forgotStep2Verify(username); });
  }

  async function _forgotStep2Verify(username) {
    var answer = document.getElementById('forgotAnswer').value.trim();
    if (!answer) { App.showToast('请输入密保答案', 'error'); return; }
    var btn = document.getElementById('btnForgotVerify'); btn.disabled = true; btn.textContent = '验证中...';
    try {
      var answerHash = await App.Utils.sha256(answer.toLowerCase());
      var ok = await App.DB.verifySecAnswer(username, answerHash);
      if (!ok) { App.showToast('密保答案错误', 'error'); return; }
      _forgotStep3(username, answerHash);
    } catch (e) { App.showToast('验证失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '验证'; }
  }

  function _forgotStep3(username, secAnswerHash) {
    var body =
      '<div class="form-group"><label>新密码</label><input type="password" id="forgotNewPwd" placeholder="请输入新密码"></div>' +
      '<div class="form-group"><label>确认新密码</label><input type="password" id="forgotNewPwd2" placeholder="再次输入新密码"></div>' +
      '<div class="form-actions"><button class="btn btn-primary" id="btnForgotReset">重置密码</button></div>';
    _showAuthCard('找回密码 (3/3)', '设置新密码', body);
    document.getElementById('btnForgotReset').addEventListener('click', function () { _forgotStep3Reset(username, secAnswerHash); });
  }

  /** v1.9.0: 走 update-password Edge Function (verify_type=sec_answer, 同步改 bcrypt + 旧哈希) */
  async function _forgotStep3Reset(username, secAnswerHash) {
    var pwd = document.getElementById('forgotNewPwd').value;
    var pwd2 = document.getElementById('forgotNewPwd2').value;
    if (!pwd) { App.showToast('请输入新密码', 'error'); return; }
    if (pwd !== pwd2) { App.showToast('两次密码不一致', 'error'); return; }
    var btn = document.getElementById('btnForgotReset'); btn.disabled = true; btn.textContent = '重置中...';
    try {
      var newPwdHash = await hashPassword(username, pwd);
      await App.DB.resetPassword(username, pwd, newPwdHash, secAnswerHash);
      App.showToast('密码重置成功, 请重新登录', 'success'); showLoginPage();
    } catch (e) { App.showToast('重置失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '重置密码'; }
  }

  // ========== 登录逻辑 (v1.9.0: Supabase Auth + 自动迁移) ==========

  /**
   * v1.9.0 登录流程:
   *   admin  → verify_login (旧机制, 不进 Auth)
   *   普通用户:
   *     1. verify_login 旧哈希校验 (防劫持 + 兼容老用户)
   *     2. getMigrationStatus 查迁移状态
   *        - 未迁移 → migrate-user Edge Function (校验旧哈希 → 建 Auth 账号 → 回填 user_id)
   *     3. Supabase Auth signIn 拿 JWT (access_token/refresh_token/uid)
   *     4. 存会话 + 旧哈希兜底
   */
  async function login(username, password) {
    if (!username || !password) { App.showToast('请输入用户名和密码', 'error'); return false; }
    try {
      var pwdHash = await hashPassword(username, password);

      // 1. admin: 旧机制 (verify_login + KEY_PWD_HASH, 不进 Supabase Auth)
      if (username === AUTH.ADMIN_CODE) {
        var adminResult = await App.DB.verifyLogin(username, pwdHash);
        if (!adminResult.success) { App.showToast('管理员密码错误', 'error'); return false; }
        localStorage.setItem(CFG.KEY_USERNAME, username);
        localStorage.setItem(CFG.KEY_PWD_HASH, pwdHash);
        App.DB.setSyncCode(username);
        return true;
      }

      // 2. 普通用户: 先用旧哈希 verify_login (防劫持 + 兼容老用户)
      var verifyResult = await App.DB.verifyLogin(username, pwdHash);
      if (!verifyResult.success) {
        App.showToast(verifyResult.error === 'user_not_found' ? '用户名不存在' : '密码错误', 'error');
        return false;
      }

      // 3. 查迁移状态, 未迁移则触发 migrate-user
      var migStatus = await App.DB.getMigrationStatus(username);
      if (!migStatus || !migStatus.migrated) {
        var migResult = await App.DB.migrateUser(username, password, pwdHash);
        if (!migResult || !migResult.success) {
          throw new Error((migResult && migResult.error) || '老用户迁移失败, 请联系管理员');
        }
      }

      // 4. Supabase Auth signIn 拿 JWT (账号已建, 密码=用户输入的明文)
      var email = _fakeEmail(username);
      var session = await _authSignIn(email, password);

      // 5. 存会话
      App.DB.setAuthSession(session.user.id, session.access_token, session.refresh_token);
      localStorage.setItem(CFG.KEY_USERNAME, username);
      localStorage.setItem(CFG.KEY_PWD_HASH, pwdHash);  // 兜底 (迁移校验 + admin 切换)
      App.DB.setSyncCode(username);
      return true;
    } catch (e) {
      console.error('[Auth.login] 失败:', e);
      var msg = e && e.message ? e.message : String(e);
      // Supabase Auth "Invalid credentials" → 密码错误
      if (msg.indexOf('Invalid credentials') >= 0 || msg.indexOf('invalid') >= 0) {
        msg = '密码错误或账号未迁移完成, 请用找回密码重置';
      }
      App.showToast('登录失败: ' + msg, 'error');
      return false;
    }
  }

  async function checkAuth(username) {
    if (username === AUTH.ADMIN_CODE) return 'admin';
    try {
      var auth = await App.DB.getAuthorization(username);
      if (!auth) {
        var userInfo = await App.DB.getUserAuthInfo(username);
        if (userInfo && userInfo.createdAt) {
          var createdMs = new Date(userInfo.createdAt).getTime();
          var trialEnd = createdMs + AUTH.TRIAL_DAYS * 24 * 60 * 60 * 1000;
          if (Date.now() < trialEnd) return 'trial';
        }
        return 'none';
      }
      if (auth.status === 'revoked') return 'expired';
      if (auth.expiresAt && new Date(auth.expiresAt).getTime() < Date.now()) return 'expired';
      return 'authorized';
    } catch (e) { console.error('[Auth] checkAuth error:', e); return 'none'; }
  }

  // ========== 捐赠/支付页 ==========

  function showDonationPage() {
    var username = getCurrentUser() || '';
    _renderDonationPage(username, null);
    App.DB.getPromoConfig().then(function (promo) { _renderDonationPage(username, promo); }).catch(function (e) { console.error('[Auth] 加载促销配置失败:', e); });
  }

  function _renderDonationPage(username, promo) {
    var promoText = (promo && promo.text) ? promo.text : '捐赠20元得1年使用权';
    var onlinePayBtn = '';
    if (App.Config.YUNGOU && App.Config.YUNGOU.CREATE_ORDER_URL) {
      onlinePayBtn = '<button id="btnOnlinePay" style="width:100%;padding:12px;background:#07C160;color:#fff;border:none;border-radius:6px;font-size:16px;font-weight:500;cursor:pointer;margin-bottom:12px;">在线支付 (微信)</button>';
    }

    var qrHtml;
    if (AUTH.WECHAT_QR) qrHtml = '<img src="' + _esc(AUTH.WECHAT_QR) + '" alt="微信收款码" style="width:180px;height:180px;border-radius:8px;border:1px solid #E0E0E0;display:block;margin:0 auto;">';
    else qrHtml = '';

    var contactHtml = AUTH.WECHAT_ID ? '<p style="font-size:13px;color:#666;margin-top:10px;">或联系微信: <b style="color:#333;">' + _esc(AUTH.WECHAT_ID) + '</b> 手动开通</p>' : '';
    var manualHtml = qrHtml ? (qrHtml + contactHtml) : (AUTH.WECHAT_ID ? contactHtml : '');

    var html =
      '<div class="auth-overlay" style="position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(135deg,#4A90D9,#357ABD);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px;box-sizing:border-box;overflow-y:auto;"> ' +
        '<div class="auth-card" style="background:#fff;border-radius:12px;padding:32px 24px;width:100%;max-width:360px;box-shadow:0 8px 32px rgba(0,0,0,0.2);text-align:center;"> ' +
          '<h2 style="font-size:22px;color:#333;margin-bottom:6px;">支持背单词</h2>' +
          '<p style="font-size:13px;color:#999;margin-bottom:18px;">当前账户: ' + _esc(username) + '</p>' +
          '<p style="font-size:15px;color:#333;margin-bottom:20px;font-weight:500;">' + _esc(promoText) + '</p>' +
          onlinePayBtn +
          (manualHtml ? '<div id="manualPaySection" style="' + (onlinePayBtn ? 'margin-top:8px;padding-top:16px;border-top:1px dashed #E0E0E0;' : '') + '">' +
            '<p style="font-size:12px;color:#999;margin-bottom:10px;">其他支付方式</p>' + manualHtml + '</div>' : '') +
          '<button id="btnRefreshAuth" style="width:100%;padding:12px;background:#4A90D9;color:#fff;border:none;border-radius:6px;font-size:16px;font-weight:500;cursor:pointer;margin-top:20px;">刷新授权</button>' +
          '<button id="btnDonationLogout" style="width:100%;padding:10px;background:transparent;color:#999;border:none;font-size:14px;cursor:pointer;margin-top:8px;">退出登录</button>' +
        '</div>' +
      '</div>';
    _showOverlay(html);
    var btnOnlinePay = document.getElementById('btnOnlinePay');
    if (btnOnlinePay) btnOnlinePay.addEventListener('click', function () { _startOnlinePay(username, promo); });
    document.getElementById('btnRefreshAuth').addEventListener('click', _refreshAuth);
    document.getElementById('btnDonationLogout').addEventListener('click', logout);
  }

  async function _startOnlinePay(username, promo) {
    var amount = (promo && promo.amount) ? promo.amount : '20';
    var promoText = (promo && promo.text) ? promo.text : '捐赠' + amount + '元得1年使用权';

    _showOverlay(
      '<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(135deg,#4A90D9,#357ABD);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px;box-sizing:border-box;">' +
        '<div style="background:#fff;border-radius:12px;padding:32px 24px;width:100%;max-width:340px;text-align:center;">' +
          '<p style="font-size:15px;color:#666;">正在创建订单...</p>' +
        '</div>' +
      '</div>'
    );

    try {
      var resp = await fetch(App.Config.YUNGOU.CREATE_ORDER_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username }),
      });
      var data = await resp.json();
      if (!data.success) throw new Error(data.error || '创建订单失败');

      var outTradeNo = data.out_trade_no;
      var qrcode = data.qrcode;
      var priceYuan = (data.total_fee / 100).toFixed(2);

      _showPayQrCode(username, outTradeNo, qrcode, priceYuan, promoText);
      _pollOrderStatus(outTradeNo, username);
    } catch (e) {
      App.showToast('创建订单失败: ' + e.message, 'error');
      showDonationPage();
    }
  }

  function _showPayQrCode(username, outTradeNo, qrcode, priceYuan, promoText) {
    var html =
      '<div class="auth-overlay" style="position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(135deg,#4A90D9,#357ABD);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px;box-sizing:border-box;overflow-y:auto;">' +
        '<div style="background:#fff;border-radius:12px;padding:32px 24px;width:100%;max-width:340px;box-shadow:0 8px 32px rgba(0,0,0,0.2);text-align:center;">' +
          '<h2 style="font-size:22px;color:#333;margin-bottom:6px;">微信扫码支付</h2>' +
          '<p style="font-size:13px;color:#999;margin-bottom:16px;">' + _esc(promoText) + '</p>' +
          '<div style="font-size:36px;font-weight:bold;color:#07C160;margin-bottom:16px;">¥' + priceYuan + '</div>' +
          '<div id="payQrContainer" style="width:220px;height:220px;margin:0 auto;border:1px solid #E0E0E0;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;">' +
            '<img id="payQrImg" src="' + _esc(qrcode) + '" alt="支付二维码" style="width:100%;height:100%;object-fit:contain;" onerror="document.getElementById(\'payQrContainer\').innerHTML=\'<div style=\\\'color:#999;font-size:13px;\\\'>二维码加载失败</div>\'">' +
          '</div>' +
          '<p id="payStatusTip" style="font-size:14px;color:#666;margin-top:16px;">请使用微信扫描二维码支付</p>' +
          '<p style="font-size:12px;color:#999;margin-top:8px;">支付成功后将自动开通授权</p>' +
          '<button id="btnPayCancel" style="width:100%;padding:10px;background:transparent;color:#999;border:none;font-size:14px;cursor:pointer;margin-top:16px;">取消支付</button>' +
        '</div>' +
      '</div>';
    _showOverlay(html);
    document.getElementById('btnPayCancel').addEventListener('click', function () {
      if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
      showDonationPage();
    });
  }

  var _pollTimer = null;
  var _pollCount = 0;

  function _pollOrderStatus(outTradeNo, username) {
    if (_pollTimer) clearInterval(_pollTimer);
    _pollCount = 0;
    var maxPolls = 300;
    _pollTimer = setInterval(async function () {
      _pollCount++;
      if (_pollCount > maxPolls) {
        if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
        var tip = document.getElementById('payStatusTip');
        if (tip) { tip.textContent = '支付超时，请重新发起支付'; tip.style.color = '#E74C3C'; }
        return;
      }
      try {
        var result = await App.DB.getPayOrderStatus(outTradeNo);
        if (result && result.success && result.status === 'paid') {
          if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
          var tip2 = document.getElementById('payStatusTip');
          if (tip2) { tip2.textContent = '支付成功，正在开通授权...'; tip2.style.color = '#27AE60'; }
          setTimeout(function () { _refreshAuth(); }, 1000);
        }
      } catch (e) { /* 轮询出错不中断 */ }
    }, 3000);
  }

  async function _refreshAuth() {
    var username = getCurrentUser();
    if (!username) { showLoginPage(); return; }
    var btn = document.getElementById('btnRefreshAuth');
    if (btn) { btn.disabled = true; btn.textContent = '检查中...'; }
    try {
      var status = await checkAuth(username);
      if (status === 'authorized' || status === 'admin' || status === 'trial') { App.showToast('授权有效, 即将进入应用', 'success'); _hideOverlay(); _startApp(); showMessagesPopup(username); }
      else App.showToast('授权尚未开通, 请捐赠后联系管理员', 'error');
    } catch (e) { App.showToast('检查失败: ' + e.message, 'error'); }
    finally { if (btn) { btn.disabled = false; btn.textContent = '刷新授权'; } }
  }

  async function showMessagesPopup(username) {
    if (!username) return;
    try {
      var messages = await App.DB.getUnreadMessages(username);
      if (!messages || messages.length === 0) return;
      var listHtml = '';
      for (var i = 0; i < messages.length; i++) {
        var m = messages[i];
        listHtml += '<div class="msg-card" data-card-id="' + m.id + '" style="border:1px solid #E0E0E0;border-radius:8px;padding:16px;margin-bottom:12px;"><h3 style="font-size:16px;color:#333;margin-bottom:8px;">' + _esc(m.title) + '</h3><div style="font-size:14px;color:#666;line-height:1.6;white-space:pre-wrap;">' + _esc(m.content) + '</div><button class="btn btn-sm btn-outline" data-msg-id="' + m.id + '" style="margin-top:10px;">已读</button></div>';
      }
      var body = '<div style="max-height:60vh;overflow-y:auto;">' + listHtml + '</div><div class="form-actions"><button class="btn btn-primary" id="btnMarkAllRead">全部已读</button></div>';
      App.showModal('系统留言 (' + messages.length + ' 条)', body);
      var buttons = document.querySelectorAll('[data-msg-id]');
      for (var j = 0; j < buttons.length; j++) {
        buttons[j].addEventListener('click', function () {
          var msgId = parseInt(this.getAttribute('data-msg-id'), 10);
          var card = this.closest('[data-card-id]');
          App.DB.markMessageRead(username, msgId).then(function () {
            if (card) card.remove();
            var remaining = document.querySelectorAll('[data-msg-id]');
            if (remaining.length === 0) App.hideModal();
          }).catch(function () { App.showToast('标记失败', 'error'); });
        });
      }
      document.getElementById('btnMarkAllRead').addEventListener('click', function () {
        var promises = [];
        for (var k = 0; k < messages.length; k++) promises.push(App.DB.markMessageRead(username, messages[k].id));
        Promise.all(promises).then(function () { App.hideModal(); App.showToast('已全部标记为已读', 'success'); }).catch(function () { App.showToast('部分标记失败', 'error'); });
      });
    } catch (e) { console.error('[Auth] showMessagesPopup error:', e); }
  }

  // ========== 会话查询 ==========

  function logout() { _clearAuthStorage(); _appStarted = false; showLoginPage(); }

  /**
   * 是否已登录:
   *   admin → 有 KEY_PWD_HASH
   *   普通用户 → 有 uid + access_token (JWT)
   */
  function isLoggedIn() {
    var username = localStorage.getItem(CFG.KEY_USERNAME);
    if (!username) return false;
    if (username === AUTH.ADMIN_CODE) {
      return !!localStorage.getItem(CFG.KEY_PWD_HASH);
    }
    return !!(App.DB.getUserId() && App.DB.getAccessToken());
  }

  function getCurrentUser() { return localStorage.getItem(CFG.KEY_USERNAME) || null; }
  function getAdminPwdHash() { return localStorage.getItem(CFG.KEY_PWD_HASH) || ''; }

  // ========== 修改密码 / 修改密保 ==========

  function changePasswordForm() {
    var username = getCurrentUser();
    if (!username) { App.showToast('请先登录', 'error'); return; }
    var body = '<div class="form-group"><label>原密码</label><input type="password" id="chgOldPwd" placeholder="请输入原密码"></div><div class="form-group"><label>新密码</label><input type="password" id="chgNewPwd" placeholder="请输入新密码"></div><div class="form-group"><label>确认新密码</label><input type="password" id="chgNewPwd2" placeholder="再次输入新密码"></div><div class="form-actions"><button class="btn btn-outline" id="btnChgPwdCancel">取消</button><button class="btn btn-primary" id="btnChgPwdSubmit">确认修改</button></div>';
    App.showModal('修改密码', body);
    document.getElementById('btnChgPwdCancel').addEventListener('click', App.hideModal);
    document.getElementById('btnChgPwdSubmit').addEventListener('click', function () { _handleChangePassword(username); });
  }

  /**
   * v1.9.0: 走 update-password Edge Function
   *   - admin: 不进 Supabase Auth, 只需改 user_auth 旧哈希 → 走 change_sec_question 不行
   *     admin 改密走旧路径 (verify_login 校验旧哈希 + 直接 PATCH user_auth)
   *     简化: admin 也走 Edge Function, verify_type=password, 内部只改 user_auth (admin 无 Auth 账号, findUserIdByEmail 返回 null, 跳过 bcrypt)
   */
  async function _handleChangePassword(username) {
    var oldPwd = document.getElementById('chgOldPwd').value;
    var newPwd = document.getElementById('chgNewPwd').value;
    var newPwd2 = document.getElementById('chgNewPwd2').value;
    if (!oldPwd) { App.showToast('请输入原密码', 'error'); return; }
    if (!newPwd) { App.showToast('请输入新密码', 'error'); return; }
    if (newPwd !== newPwd2) { App.showToast('两次新密码不一致', 'error'); return; }
    var btn = document.getElementById('btnChgPwdSubmit'); btn.disabled = true; btn.textContent = '修改中...';
    try {
      var oldHash = await hashPassword(username, oldPwd);
      var newHash = await hashPassword(username, newPwd);
      await App.DB.changePassword(username, oldPwd, newPwd, oldHash, newHash);
      localStorage.setItem(CFG.KEY_PWD_HASH, newHash);
      App.showToast('密码修改成功', 'success'); App.hideModal();
    } catch (e) { App.showToast('修改失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '确认修改'; }
  }

  function changeSecQuestionForm() {
    var username = getCurrentUser();
    if (!username) { App.showToast('请先登录', 'error'); return; }
    var options = '';
    for (var i = 0; i < CFG.SEC_QUESTIONS.length; i++) options += '<option value="' + i + '">' + _esc(CFG.SEC_QUESTIONS[i]) + '</option>';
    var body = '<div class="form-group"><label>密码验证</label><input type="password" id="chgSecPwd" placeholder="请输入当前密码"></div><div class="form-group"><label>新密保问题</label><select id="chgSecQuestion">' + options + '</select></div><div class="form-group"><label>新密保答案</label><input type="text" id="chgSecAnswer" placeholder="请输入新密保答案" autocomplete="off"></div><div class="form-actions"><button class="btn btn-outline" id="btnChgSecCancel">取消</button><button class="btn btn-primary" id="btnChgSecSubmit">确认修改</button></div>';
    App.showModal('修改密保问题', body);
    document.getElementById('btnChgSecCancel').addEventListener('click', App.hideModal);
    document.getElementById('btnChgSecSubmit').addEventListener('click', function () { _handleChangeSecQuestion(username); });
  }

  /** 修改密保: 走 change_sec_question RPC (需密码校验, 仅改 user_auth, 不涉及 bcrypt) */
  async function _handleChangeSecQuestion(username) {
    var pwd = document.getElementById('chgSecPwd').value;
    var secQIdx = parseInt(document.getElementById('chgSecQuestion').value, 10);
    var secAnswer = document.getElementById('chgSecAnswer').value.trim();
    if (!pwd) { App.showToast('请输入密码', 'error'); return; }
    if (!secAnswer) { App.showToast('请输入密保答案', 'error'); return; }
    var btn = document.getElementById('btnChgSecSubmit'); btn.disabled = true; btn.textContent = '修改中...';
    try {
      var pwdHash = await hashPassword(username, pwd);
      var secAnswerHash = await App.Utils.sha256(secAnswer.toLowerCase());
      var secQuestion = CFG.SEC_QUESTIONS[secQIdx];
      await App.DB.changeSecQuestion(username, pwdHash, secQuestion, secAnswerHash);
      App.showToast('密保问题修改成功', 'success'); App.hideModal();
    } catch (e) { App.showToast('修改失败: ' + e.message, 'error'); }
    finally { btn.disabled = false; btn.textContent = '确认修改'; }
  }

  return {
    init: init, hashPassword: hashPassword, showLoginPage: showLoginPage, showRegisterPage: showRegisterPage,
    showForgotPasswordPage: showForgotPasswordPage, login: login, checkAuth: checkAuth, showDonationPage: showDonationPage,
    showMessagesPopup: showMessagesPopup, logout: logout, isLoggedIn: isLoggedIn, getCurrentUser: getCurrentUser,
    getAdminPwdHash: getAdminPwdHash, changePasswordForm: changePasswordForm, changeSecQuestionForm: changeSecQuestionForm,
  };
})();

// ES Module 导出 (供 main.js 显式 import, 同时 window.App.Auth 命名空间保留供业务模块使用)
export default App.Auth;
